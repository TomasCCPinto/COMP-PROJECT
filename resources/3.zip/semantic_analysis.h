
#ifndef __SEMANTIC_ANALYSIS_H
#define __SEMANTIC_ANALYSIS_H

#include "ast.h"





void semantic_analysis(ast_node_t *node);

#endif 
